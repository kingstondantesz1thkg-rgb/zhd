---
title: Hello World
---
欢迎来到 [郑泓达的博客](https://hexo.io/)！这是你的第一篇文章。查看 [文档](https://hexo.io/zh-cn/docs/) 了解更多信息。如果在使用中遇到任何问题，可以在 [故障排查](https://hexo.io/zh-cn/docs/troubleshooting.html) 中找到答案，或者在 [GitHub](https://github.com/hexojs/hexo/issues) 上向我提问。

## 快速开始

### 创建新文章

``` bash
$ hexo new "我的新文章"
```

更多信息：[写作](https://hexo.io/zh-cn/docs/writing.html)

### 启动服务器

``` bash
$ hexo server
```

更多信息：[服务器](https://hexo.io/zh-cn/docs/server.html)

### 生成静态文件

``` bash
$ hexo generate
```

更多信息：[生成](https://hexo.io/zh-cn/docs/generating.html)

### 部署到远程站点

``` bash
$ hexo deploy
```

更多信息：[部署](https://hexo.io/zh-cn/docs/one-command-deployment.html)
