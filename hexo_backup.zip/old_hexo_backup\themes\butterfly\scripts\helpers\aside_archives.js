'use strict'

hexo.extend.helper.register('aside_archives', function (options = {}) {
  const { config, page, site, url_for: urlFor, _p } = this
  const { archive_dir: archiveDir, timezone, language } = config

  // Destructure and set default options with object destructuring
  const {
    type = 'monthly',
    format = type === 'monthly' ? 'MMMM YYYY' : 'YYYY',
    show_count: showCount = true,
    order = -1,
    limit,
    transform
  } = options

  // Optimize locale handling
  const lang = toMomentLocale(page.lang || page.language || language)

  // Early return if no posts
  if (!site.posts.length) return ''

  const archives = new Map()
  site.posts.forEach(post => {
    const date = post.date
    const year = date.year()
    const month = date.month() + 1
    const key = type === 'yearly' ? year : `${year}-${month}`

    if (archives.has(key)) {
      archives.get(key).count++
    } else {
      archives.set(key, {
        year,
        month,
        count: 1,
        date // Store date object for later formatting
      })
    }
  })

  const data = Array.from(archives.values()).sort((a, b) => {
    if (order === -1) {
      return b.year - a.year || b.month - a.month
    }
    return a.year - b.year || a.month - b.month
  })

  // Format names after aggregation
  data.forEach(item => {
    let date = item.date.clone()
    if (timezone) date = date.tz(timezone)
    if (lang) date = date.locale(lang)
    item.name = date.format(format)
    delete item.date // Clean up
  })

  // Create link generator function
  const createArchiveLink = item => {
    let url = `${archiveDir}/${item.year}/`
    if (type === 'monthly') {
      url += item.month < 10 ? `0${item.month}/` : `${item.month}/`
    }
    return urlFor(url)
  }

  // Limit results efficiently
  const limitedData = limit > 0 ? data.slice(0, Math.min(data.length, limit)) : data

  // Use template literal for better readability
  const archiveHeader = `
    <div class="item-headline">
      <i class="fas fa-archive"></i>
      <span>${_p('aside.card_archives')}</span>
      ${
        data.length > limitedData.length
          ? `<a class="card-more-btn" href="${urlFor(archiveDir)}/"
            title="${_p('aside.more_button')}">
            <i class="fas fa-angle-right"></i>
          </a>`
          : ''
      }
    </div>
  `

  // Use map for generating list items, join for performance
  const archiveList = `
    <ul class="card-archive-list">
      ${limitedData
        .map(
          item => `
        <li class="card-archive-list-item">
          <a class="card-archive-list-link" href="${createArchiveLink(item)}">
            <span class="card-archive-list-date">
              ${transform ? transform(item.name) : item.name}
            </span>
            ${showCount ? `<span class="card-archive-list-count">${item.count}</span>` : ''}
          </a>
        </li>
      `
        )
        .join('')}
    </ul>
  `

  return archiveHeader + archiveList
})

// Improved locale conversion function
const toMomentLocale = lang => {
  if (!lang || ['en', 'default'].includes(lang)) return 'en'
  return lang.toLowerCase().replace('_', '-')
}
